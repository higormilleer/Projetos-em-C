/*Implemente um método que receba três filas, duas já preenchidas em
ordem crescente e preencha a última com os valores das duas primeiras
em ordem crescente.*/

#include <stdio.h>

int main()
{
    printf("Hello World");

    return 0;
}

