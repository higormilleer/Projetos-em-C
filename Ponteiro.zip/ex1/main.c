/*) Sendo p um ponteiro, qual a diferença entre:
• p++; o valor de p recebe o incremente de 1
• (*p)++; o valor de onde o ponteiro esta apotando e adcionado a 1
• *(p++); utilizado para apontar para o proximo local de uma memoria, sem incrementar, o "p++" e utilizado para apenas avançar, por exemplo em um vetor

• O que quer dizer *(p+10); Ira acesssar o numero que esta localizado 10 posicoes para frente, sem contar o primeiro numero
*/



